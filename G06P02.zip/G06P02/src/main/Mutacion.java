package main;

public interface Mutacion {
	//NUEVOS
	public void insercion(int funcion);
	public void intercambio(int funcion);
	public void inversion(int funcion);
	public void heuristica(int funcion);
	public void metodopropioMUT(int funcion);
}
